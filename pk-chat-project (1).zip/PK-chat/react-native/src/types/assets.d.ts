declare module '*.jpeg' {
  const value: number;
  export default value;
}

declare module '*.png' {
  const value: number;
  export default value;
}
